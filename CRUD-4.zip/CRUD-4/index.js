const express = require('express')
const port = 8080

const app = express()
app.use(express.urlencoded())

app.set('view engine' , 'ejs')

let studentData = [
    {
        userId:1,
        name:"krishna",
        email:"kk@gmail.com",
        phone:123456789,
        password:"123@kk"
    },
    {
        userId:2,
        name:"tisha",
        email:"kk@gmail.com",
        phone:123456789,
        password:"123@kk"
    },
    {
        userId:3,
        name:"litss",
        email:"kk@gmail.com",
        phone:123456789,
        password:"123@kk"
    },
    {
        userId:4,
        name:"joy",
        email:"kk@gmail.com",
        phone:123456789,
        password:"123@kk"
    },
    {
        userId:5,
        name:"joii",
        email:"kk@gmail.com",
        phone:123456789,
        password:"123@kk"
    },
]

app.get('/',(req,res)=>{
    return res.render('form',{  
        student:studentData
    })
})


app.post('/insertData',(req,res)=>{
    let userId = req.body.userId;
    let name = req.body.name;
    let email = req.body.email;
    let phone = req.body.phone;
    let password = req.body.password;

    let obj = {
        userId : userId,
        name : name,
        email:email,
        phone:phone,
        password:password
    }

    studentData.push(obj)
    console.log("ok")
    return res.redirect('back')
})

app.listen(port,(err)=>{
    if(err){
        console.log("Server not started")
    }else{
        console.log("Server Started at " + port)
    }
})